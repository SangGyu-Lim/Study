#include "stdafx.h"
#include "EndScene.h"

CEndScene::CEndScene()
{
	cout << "EndScene ������" << endl;
	init();
}

CEndScene::~CEndScene()
{
	release();
	cout << "EndScene �Ҹ���" << endl;
}

void CEndScene::init()
{

}

void CEndScene::render()
{

}

void CEndScene::update()
{

}

void CEndScene::release()
{

}

