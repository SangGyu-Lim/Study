#include "stdafx.h"
#include "GameScene.h"

CGameScene::CGameScene()
{
	cout << "GameScene ������" << endl;
	init();
}

CGameScene::~CGameScene()
{
	release();
	cout << "GameScene �Ҹ���" << endl;
}

void CGameScene::init()
{

}

void CGameScene::render()
{

}

void CGameScene::update()
{

}

void CGameScene::release()
{

}

