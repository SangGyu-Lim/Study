#include "stdafx.h"
#include "MainScene.h"

CMainScene::CMainScene()
{
	cout << "MainScene ������" << endl;
	init();
}

CMainScene::~CMainScene()
{
	release();
	cout << "MainScene �Ҹ���" << endl;
}

void CMainScene::init()
{

}

void CMainScene::render()
{

}

void CMainScene::update()
{

}

void CMainScene::release()
{

}

