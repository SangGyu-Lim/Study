#include "stdafx.h"
#include "LoginScene.h"

CLoginScene::CLoginScene()
{
	cout << "LoginScene ������" << endl;
	init();
}

CLoginScene::~CLoginScene()
{
	release();
	cout << "LoginScene �Ҹ���" << endl;
}

void CLoginScene::init()
{

}

void CLoginScene::render()
{

}

void CLoginScene::update()
{

}

void CLoginScene::release()
{

}

