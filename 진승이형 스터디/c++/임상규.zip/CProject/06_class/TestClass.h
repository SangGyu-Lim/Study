#ifndef __TESTCLASS_H__
#define __TESTCLASS_H__

class testclass{
private:

protected:

public:
	testclass();
	~testclass();
};

#endif