#include "stdafx.h"
#include "TestClass.h"

testclass::testclass()
{

}

testclass::~testclass()
{

}