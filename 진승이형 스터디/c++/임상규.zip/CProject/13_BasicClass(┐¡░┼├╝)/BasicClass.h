#ifndef __BASIC_CLASS_H__
#define __BASIC_CLASS_H__

class CStudent
{
public:
	enum eItem
	{
		eITEM_NAME,
		eITEM_PHONE_NUM,
		eITEM_GRADE,
		eITEM_DEPARTMENT
	};

private:
	enum eGrade
	{
		eGRADE_1,
		eGRADE_2,
		eGRADE_3,
		eGRADE_4,
		eGRADE_MAX
	};

	enum eDepartment
	{
		eDEPARTMENT_COMPUTER_ENGINEERING,
		eDEPARTMENT_DIGITAL_CONTENTS,
		eDEPARTMENT_DANCE,
		eDEPARTMENT_ENGLISH,
		eDEPARTMENT_MAX
	};

	typedef struct _sStudent
	{
		char Name[256];		
		int StudentNum;
		eDepartment Department;
		eGrade Grade;		
		char PhoneNum[256];
	} STUDENT, *LPSTUDENT;	

	LPSTUDENT m_Student;
	int m_StudentCount;

protected:

public:
	CStudent();
	~CStudent();

	bool addStudent();
	bool insertStudentInfo();
	bool deleteStudentInfo( int StudentNum );
	bool modifyStudentInfo( int StudentNum, eItem Item, void *pValue );
	bool saveStudent();
	bool loadStudent();
	void printStudent();

};

#endif