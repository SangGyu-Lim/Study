#include <iostream>
#include "BasicClass.h"

using namespace std;

void main()
{
	int menu = 1;
	CStudent Student;	

	while( menu )
	{
		cout << "1. �Է�" << endl
			<< "2. ����" << endl
			<< "3. ����" << endl
			<< "4. ����" << endl
			<< "5. �ε�" << endl
			<< "6. ����" << endl
			<< "�Է� : ";

		cin >> menu;

		switch( menu )
		{
		case 1:
			{
				Student.addStudent();
			} break;
		case 2:
			{
				int tempStudentNum;

				cout << "���� �� �й� �Է� : ";
				cin >> tempStudentNum;

				Student.deleteStudentInfo( tempStudentNum );
			} break;
		case 3:
			{

			} break;
		case 4:
			{

			} break;
		case 5:
			{

			} break;
		case 6:
			{
				menu = 0;
			} break;
		}
	}
	
	
}
