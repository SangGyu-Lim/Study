#include <iostream>
#include "BasicClass.h"

using namespace std;

CStudent::CStudent()
	: m_Student( NULL )
	, m_StudentCount( 0 )
{

}

CStudent::~CStudent()
{
	delete[] m_Student;
	m_Student = NULL;
}

bool CStudent::addStudent()
{
	if( m_StudentCount == 0 )
	{
		m_Student = new STUDENT[ m_StudentCount + 1 ];		
	}
	else
	{
		LPSTUDENT tempStudent = new STUDENT[ m_StudentCount ];

		if( tempStudent )
		{
			for( int i = 0; i < m_StudentCount; i++)
			{
				memcpy( &tempStudent[ i ], &m_Student[ i ], sizeof( STUDENT ) );
			}

			if( m_Student )
			{
				delete[] m_Student;
				m_Student = NULL;
			}

			m_Student = new STUDENT[ m_StudentCount + 1 ];

			if( m_Student )
			{
				for( int i = 0; i < m_StudentCount; i++)
				{
					memcpy( &m_Student[ i ], &tempStudent[ i ], sizeof( STUDENT ) );
				}

				if( tempStudent )
				{
					delete[] tempStudent;
					tempStudent = NULL;
				}
			}
			else
				return false;
		}
		else
			return false;

	}

	if( insertStudentInfo() )
	{
		m_StudentCount++;

		printStudent();
		return true;
	}
	else
		return false;
	
}

bool CStudent::insertStudentInfo()
{
	int tempIndex;

	cout << "�̸� : ";
	cin >> m_Student[ m_StudentCount ].Name;

	cout << "�й� : ";	
	cin >> m_Student[ m_StudentCount ].StudentNum;

	cout << "�а� : ";
	cin >> tempIndex;
	if( ( tempIndex >= 0 ) && ( tempIndex < eDEPARTMENT_MAX ) )
	{
		switch( tempIndex )
		{
		case eDEPARTMENT_COMPUTER_ENGINEERING:
			{
				m_Student[ m_StudentCount ].Department = eDEPARTMENT_COMPUTER_ENGINEERING;
			} break;
		case eDEPARTMENT_DIGITAL_CONTENTS:
			{
				m_Student[ m_StudentCount ].Department = eDEPARTMENT_DIGITAL_CONTENTS;
			} break;
		case eDEPARTMENT_DANCE:
			{
				m_Student[ m_StudentCount ].Department = eDEPARTMENT_DANCE;
			} break;
		case eDEPARTMENT_ENGLISH:
			{
				m_Student[ m_StudentCount ].Department = eDEPARTMENT_ENGLISH;
			} break;			
		}
	}
	else
		return false;

	cout << "�г� : ";
	cin >> tempIndex;
	if( ( tempIndex >= 0 ) && ( tempIndex < eGRADE_MAX ) )
	{
		switch( tempIndex )
		{
		case eGRADE_1:
			{
				m_Student[ m_StudentCount ].Grade = eGRADE_1;
			} break;
		case eGRADE_2:
			{
				m_Student[ m_StudentCount ].Grade = eGRADE_2;
			} break;
		case eGRADE_3:
			{
				m_Student[ m_StudentCount ].Grade = eGRADE_3;
			} break;
		case eGRADE_4:
			{
				m_Student[ m_StudentCount ].Grade = eGRADE_4;
			} break;			
		}
	}
	else
		return false;

	cout << "��ȣ : ";
	cin >> m_Student[ m_StudentCount ].PhoneNum;

	return true;
}

bool CStudent::deleteStudentInfo( int StudentNum )
{
	if( m_StudentCount == 0 )
		return false;
	else
	{
		LPSTUDENT tempStudent = new STUDENT[ m_StudentCount - 1 ];

		if( tempStudent )
		{
			int tempIndex = 0;

			for( int i = 0; i < m_StudentCount; i++)
			{
				if( StudentNum != m_Student[ i ].StudentNum )
				{
					memcpy( &tempStudent[ tempIndex ], &m_Student[ i ], sizeof( STUDENT ) );
					tempIndex++;
				}
			}

			if( m_Student )
			{
				delete[] m_Student;
				m_Student = NULL;
			}
						
			m_Student = new STUDENT[ m_StudentCount - 1 ];

			if( m_Student )
			{
				for( int i = 0; i < ( m_StudentCount - 1 ); i++)
				{
					memcpy( &m_Student[ i ], &tempStudent[ i ], sizeof( STUDENT ) );
				}

				if( tempStudent )
				{
					delete[] tempStudent;
					tempStudent = NULL;
				}
			}
			else
				return false;
		}
		else
			return false;

	}	

	m_StudentCount--;
	printStudent();
	return true;
}

bool CStudent::modifyStudentInfo( int StudentNum, eItem Item, void *pValue )
{
	return true;
}

bool CStudent::saveStudent()
{
	return true;
}

bool CStudent::loadStudent()
{
	return true;
}

void CStudent::printStudent()
{
	for( int i = 0; i < m_StudentCount; i++)
	{
		cout << "�̸� : " << m_Student[ i ].Name << endl
			<< "�й� : " << m_Student[ i ].StudentNum << endl
			<< "�а� : " << m_Student[ i ].Department << endl
			<< "�г� : " << m_Student[ i ].Grade << endl
			<< "��ȣ : " << m_Student[ i ].PhoneNum << endl
			<< endl;
	}
}
