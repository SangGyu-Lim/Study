#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	printf("Welcome to SJCE\n");
	system("pause");

	return 0;
}