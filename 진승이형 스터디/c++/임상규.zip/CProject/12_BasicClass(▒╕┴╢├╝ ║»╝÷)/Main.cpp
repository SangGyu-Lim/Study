#include <iostream>
#include <Windows.h>
#include "BasicClass.h"

using namespace std;

void main()
{
	CStudent Student;

	int StudentNumber;
	int Grade;
	char Name[256];

	cin >> StudentNumber;
	cin >> Grade;
	cin >> Name;

	Student.setStudentNumber( StudentNumber );
	Student.setGrade( Grade );
	Student.setName( Name );

	cout << Student.getStudentNumber() << endl
		<< Student.getGrade() << endl
		<< Student.getName() << endl;

	Sleep( 1500 );
}
