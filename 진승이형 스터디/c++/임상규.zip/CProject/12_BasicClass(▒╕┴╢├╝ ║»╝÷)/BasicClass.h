#ifndef __BASIC_CLASS_H__
#define __BASIC_CLASS_H__

class CStudent
{
private:
	typedef struct _sStudent
	{
		int StudentNumber;
		int Grade;
		char* Name;
	} STUDENT, *LPSTUDENT;

	LPSTUDENT m_Student;

protected:

public:
	CStudent();
	~CStudent();

	inline int		getStudentNumber()	{	return m_Student->StudentNumber;	}
	inline int		getGrade()			{	return m_Student->Grade;	}
	inline char*	getName()			{	return m_Student->Name;	}

	inline void	setStudentNumber( int StudentNumber )	{	this->m_Student->StudentNumber = StudentNumber;	}
	inline void	setGrade( int Grade )					{	this->m_Student->Grade = Grade;	}
	inline void	setName( char* Name )					{	this->m_Student->Name = Name;	}

	void init();
	void release();

};

#endif