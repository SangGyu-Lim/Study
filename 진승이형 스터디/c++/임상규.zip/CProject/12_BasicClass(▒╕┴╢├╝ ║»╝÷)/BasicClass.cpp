#include <iostream>
#include "BasicClass.h"

using namespace std;

CStudent::CStudent()
	: m_Student( NULL )
{
	init();
}

CStudent::~CStudent()
{
	release();
}

void CStudent::init()
{
	m_Student = new STUDENT;
}

void CStudent::release()
{
	if( m_Student )
	{
		delete m_Student;
	}
}