#include <iostream>
#include "BasicClass.h"

using namespace std;

CBasicClass::CBasicClass()
	: m_Num( 0 )
	, m_Sum( 0 )
{

}

CBasicClass::~CBasicClass()
{

}

void CBasicClass::squareNum()
{
	m_Sum = m_Num * m_Num;
}
