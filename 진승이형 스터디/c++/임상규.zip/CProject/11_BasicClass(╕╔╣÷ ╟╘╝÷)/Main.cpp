#include <iostream>
#include <Windows.h>
#include "BasicClass.h"

using namespace std;

void main()
{
	CBasicClass BasicClass;
	int Num;

	cin >> Num;

	BasicClass.setNum( Num );
	BasicClass.squareNum();
	cout << BasicClass.getSum() << endl;

	Sleep( 1500 );
}
