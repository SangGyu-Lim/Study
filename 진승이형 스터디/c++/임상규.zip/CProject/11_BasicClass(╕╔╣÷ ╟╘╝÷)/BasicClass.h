#ifndef __BASIC_CLASS_H__
#define __BASIC_CLASS_H__

class CBasicClass
{
private:
	int m_Num;
	int m_Sum;

protected:

public:
	CBasicClass();
	~CBasicClass();

	inline void setNum( int num )	{	m_Num = num;	}

	inline int getSum()				{	return m_Sum;	}

	void squareNum();

};

#endif