#include "stdafx.h"
#include "GameObject.h"

CGameObject::CGameObject()
	: m_CurrentX( MINIMUM ), m_CurrentY( MINIMUM )
{

}

CGameObject::~CGameObject()
{

}