#include "stdafx.h"
#include "SceneState.h"

int _tmain(int argc, _TCHAR* argv[])
{
	CSceneState SceneState;

	return 0;
}

