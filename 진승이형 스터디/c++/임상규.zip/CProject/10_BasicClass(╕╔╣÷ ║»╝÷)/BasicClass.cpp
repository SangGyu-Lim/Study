#include <iostream>
#include "BasicClass.h"

using namespace std;

int CBasicClass::m_Count = 0;

CBasicClass::CBasicClass()
	: m_Pi( 3.14f )
	, m_PrivateCount( m_Count )
{
	cout << "�������Դϴ�." << endl;
	m_Count++;
}

CBasicClass::~CBasicClass()
{
	cout << "�Ҹ����Դϴ�." << endl;
}
