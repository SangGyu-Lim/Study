#ifndef __BASIC_CLASS_H__
#define __BASIC_CLASS_H__

class CBasicClass
{
private:
	static int m_Count;
	const float m_Pi;
	int m_PrivateCount;

protected:

public:
	CBasicClass();
	~CBasicClass();

	inline int getCount()			{	return m_Count;	}	
	inline int getPrivateCount()	{	return m_PrivateCount;	}
	inline float getPi()			{	return m_Pi;	}

};

#endif
