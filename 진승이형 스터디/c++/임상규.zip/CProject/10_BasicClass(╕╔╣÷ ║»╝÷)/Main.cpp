#include <iostream>
#include <Windows.h>
#include "BasicClass.h"

using namespace std;

void main()
{
	int num;

	cin >> num;

	CBasicClass* pBasicClass = new CBasicClass[num];

	for( int i = 0; i < num; i++ )
	{
		cout << pBasicClass[i].getPrivateCount() << endl
			<< pBasicClass[i].getPi() << endl;
	}

	delete[] pBasicClass;

	Sleep( 3000 );

}
